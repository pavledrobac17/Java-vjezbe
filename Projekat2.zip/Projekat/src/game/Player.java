package game;

public class Player {

	private String ime;
	private int x;
	private int y;
	private int width;
	private int height;
	private int health;
	
	public Player(String ime, int x, int y, int widht, int height, int health) {
		this.ime = ime;
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.health = health;
		
		//Provjerava je li string prazan i sredjuje ga i posle provjerava je li health izmedju 0 i 100
		if(ime.isEmpty()) {
			System.out.print("Unesite ime!!!");
		}else {
			ime.toUpperCase().trim();
			ime.split("\\s+");
		}
		if (health > 0 && health < 100) {
			
		}else {
			System.out.println("Nesto nije u redu!");
		}
	}

	public String getIme() {
		return ime;
	}

	public void setIme(String ime) {
		this.ime = ime;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}
	//Ispisuje sve o igracu

	public String toString() {
		return "Ime: " + "[" + ime + " ]" +" X i y: " + x + y + " Width: " + width + " Height: " + height + " Health: " + health;
	}
}
