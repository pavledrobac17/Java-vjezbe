package game;

import java.awt.Event;
import java.util.ArrayList;

public class Game {

	public static void main(String[] args) {
		/*Pavle Drobac 24/025
		 * Josipovic Petar 22/024;
		 * */
		ArrayList<Enemy> enemy = new ArrayList<>();
		ArrayList<String> eventlog = new ArrayList<>();
		
		enemy.add(new Enemy(10, 7, 15, 20, "Ramos", 70));
		enemy.add(new Enemy(4, 7, 5, 2, "Pepe", 75));
		enemy.add(new Enemy(13, 6, 17, 30, "Maldini", 80));
		enemy.add(new Enemy(19, 3, 14, 10, "Vidic", 90));
		
		

	}

}
