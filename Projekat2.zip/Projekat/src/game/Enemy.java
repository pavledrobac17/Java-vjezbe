package game;

public class Enemy {

	private int xN;
	private int yN;
	private int widthN;
	private int heightN;
	private String type;
	private int dmg;
	
	public Enemy(int xN, int yN, int widthN, int heightN, String type, int healthN) {
		this.xN = xN;
		this.yN = yN;
		this.dmg = dmg;
		this.heightN = heightN;
		this.type = type;
		this.widthN = widthN;
		
		//Provjerava je li string prazan i sredjuje ga i posle provjerava je li health izmedju 0 i 100
		if (type.isEmpty()) {
			System.out.print("Unesite tip neprijatelja!!! ");
		}else {
			type.trim();
			type.toLowerCase();
		}
		if (dmg > 0 && dmg < 100) {
			
		}else {
			System.out.println("Nesto nije u redu!");
		}
	}

	public int getxN() {
		return xN;
	}

	public void setxN(int xN) {
		this.xN = xN;
	}

	public int getyN() {
		return yN;
	}

	public void setyN(int yN) {
		this.yN = yN;
	}

	public int getWidthN() {
		return widthN;
	}

	public void setWidthN(int widthN) {
		this.widthN = widthN;
	}

	public int getHeightN() {
		return heightN;
	}

	public void setHeightN(int heightN) {
		this.heightN = heightN;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getDmg() {
		return dmg;
	}

	public void setDmg(int healthN) {
		this.dmg = healthN;
	}
	//Ispisuje sve o neprijatelju
	public String toString() {
		return "Type:" +"[" + type  + "]"+ " X i y: " + "(" + xN + yN + ")" + " Width: " + widthN + " Height: " + heightN + " Dmg= " + dmg;
	}
}
