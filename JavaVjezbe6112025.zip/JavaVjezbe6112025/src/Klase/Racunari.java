package Klase;

public class Racunari extends klasaEProizvodi {

	private String procesor;
	private int memorija;
	
	public Racunari(String opisProizvoda, String sifraPriozvoda, int uvoznaCjena, String procesor, int memorija) {
		super(opisProizvoda, sifraPriozvoda, uvoznaCjena);
		this.procesor = procesor;
		this.memorija = memorija;
	}

	public String getProcesor() {
		return procesor;
	}

	public void setProcesor(String procesor) {
		this.procesor = procesor;
	}

	public int getMemorija() {
		return memorija;
	}

	public void setMemorija(int memorija) {
		this.memorija = memorija;
	}

	@Override
	public String toString() {
		return "Racunari [procesor=" + procesor + ", memorija=" + memorija + "]";
	}
	
	
	
	

}
