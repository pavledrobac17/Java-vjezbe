//Pavle Drobac 24025
package Klase;

public class klasaEProizvodi {

	private String opisProizvoda;
	private String sifraPriozvoda;
	private int uvoznaCjena;
	public klasaEProizvodi(String opisProizvoda, String sifraPriozvoda, int uvoznaCjena) {
		super();
		this.opisProizvoda = opisProizvoda;
		this.sifraPriozvoda = sifraPriozvoda;
		this.uvoznaCjena = uvoznaCjena;
	}
	public String getOpisProizvoda() {
		return opisProizvoda;
	}
	public void setOpisProizvoda(String opisProizvoda) {
		this.opisProizvoda = opisProizvoda;
	}
	public String getSifraPriozvoda() {
		return sifraPriozvoda;
	}
	public void setSifraPriozvoda(String sifraPriozvoda) {
		this.sifraPriozvoda = sifraPriozvoda;
	}
	public int getUvoznaCjena() {
		return uvoznaCjena;
	}
	public void setUvoznaCjena(int uvoznaCjena) {
		this.uvoznaCjena = uvoznaCjena;
	}
	@Override
	public String toString() {
		return "klasaEProizvodi [opisProizvoda=" + opisProizvoda + ", sifraPriozvoda=" + sifraPriozvoda
				+ ", uvoznaCjena=" + uvoznaCjena + "]";
	}
	
	
	
	
}
