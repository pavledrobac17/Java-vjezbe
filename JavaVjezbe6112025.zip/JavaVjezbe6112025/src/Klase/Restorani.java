package Klase;

public class Restorani {

    public String naziv;
    public String adresa;
    public String pib;

    public Restorani(String naziv, String adresa, String pib) {
        this.naziv = naziv;
        this.adresa = adresa;
        this.pib = pib;
    }
}