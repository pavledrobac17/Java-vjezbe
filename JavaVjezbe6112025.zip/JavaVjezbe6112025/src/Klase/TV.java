package Klase;

public class TV extends klasaEProizvodi {
private double velicinaEkrana;


public TV(String opisProizvoda, String sifraPriozvoda, int uvoznaCjena, double velicinaEkrana) {
	super(opisProizvoda, sifraPriozvoda, uvoznaCjena);
	this.velicinaEkrana = velicinaEkrana;
}


public double getVelicinaEkrana() {
	return velicinaEkrana;
}


public void setVelicinaEkrana(double velicinaEkrana) {
	this.velicinaEkrana = velicinaEkrana;
}


@Override
public String toString() {
	return "TV [velicinaEkrana=" + velicinaEkrana + "]";
}

	
}
