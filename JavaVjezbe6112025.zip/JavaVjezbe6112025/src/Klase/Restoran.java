package Klase;

public class Restoran {

}
