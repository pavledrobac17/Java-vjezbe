package Klase;

public class Zaposleni {

	public String id;
    public String ime;
    public String prezime;
    public String tip;
    public double plataPoSatu;
    public int satiSedmicno;
    public int prekovremeniSedmicno;
    public double bonus;
    
    public Zaposleni(String id, String ime, String prezime, String tip, double plataPoSatu, int satiSedmicno, int prekovremeniSedmicno, double bonus) {
        this.id = id;
        this.ime = ime;
        this.prezime = prezime;
        this.tip = tip;
        this.plataPoSatu = plataPoSatu;
        this.satiSedmicno = satiSedmicno;
        this.prekovremeniSedmicno = prekovremeniSedmicno;
        this.bonus = bonus;
    
    }

}
