package Klase;

public class Telefoni extends klasaEProizvodi {

	private String operativniSistem;
	private double velicinaEkrana;
	public Telefoni(String opisProizvoda, String sifraPriozvoda, int uvoznaCjena, String operativniSistem,
			double velicinaEkrana) {
		super(opisProizvoda, sifraPriozvoda, uvoznaCjena);
		this.operativniSistem = operativniSistem;
		this.velicinaEkrana = velicinaEkrana;
	}
	public String getOperativniSistem() {
		return operativniSistem;
	}
	public void setOperativniSistem(String operativniSistem) {
		this.operativniSistem = operativniSistem;
	}
	public double getVelicinaEkrana() {
		return velicinaEkrana;
	}
	public void setVelicinaEkrana(double velicinaEkrana) {
		this.velicinaEkrana = velicinaEkrana;
	}
	@Override
	public String toString() {
		return "Telefoni [operativniSistem=" + operativniSistem + ", velicinaEkrana=" + velicinaEkrana + "]";
	}
	
}
	
	