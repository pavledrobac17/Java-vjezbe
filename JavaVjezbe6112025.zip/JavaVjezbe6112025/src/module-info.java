/**
 * 
 */
/**
 * 
 */
module JavaVjezbe6112025 {
}