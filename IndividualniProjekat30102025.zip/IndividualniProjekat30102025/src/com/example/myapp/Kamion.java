package com.example.myapp;

public class Kamion extends Vozilo {
	private double kapacitetTereta;
	private boolean prikolica;
	

	

	}

}
