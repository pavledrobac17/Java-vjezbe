package com.example.myapp;

public class Automobil extends Vozilo {
	private int broj_vrata ; 
	private String tipMotora;
	
	Public Automobil(String proizvodjac, int godinaProizvodnje, int kubikaza, String boja, )

		

	}

}
