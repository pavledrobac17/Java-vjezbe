package com.example.myapp;

public class Kombi extends Vozilo {
	
	private int kapacitetPutnika;
	

	}

}
