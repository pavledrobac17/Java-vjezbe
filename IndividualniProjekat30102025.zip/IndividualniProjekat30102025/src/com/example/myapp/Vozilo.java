package com.example.myapp;

public class Vozilo {
		
	protected String proizvodjac; 
	protected int godinaProizvodnje;
	protected int kubikaza;
	protected String boja;
	
		public Vozilo(String proizvodjac , int godinaProizvod , int kubikaza , String boja );
	 
	
	

	}


