//Jelena Zarubica 24065
//Pavle Drobac 24025

package com.example.myapp;

 public class GameObject {

 private int x;
 private int y;
 private int width;
 private int height; {
	 this.x = x; 
	 this.y = y;
 }
 
 public void draw() {
	 System.out.println("Crtanje GameObject");
 }
 public  String toString() {
	 return "GameObject (" + x + " , " + y + ") " + width + "x" + height; 
	 
	 
 }
	 	
	}

