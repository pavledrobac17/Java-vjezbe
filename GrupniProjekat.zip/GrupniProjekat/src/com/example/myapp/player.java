package com.example.myapp;

public class player extends GameObject {

	{
    private String Ime_Igraca;
    private int health;
    
    public Player(String Ime_Igraca, int x , int y , int width, int height, int health) {	
    	super (x, y, width, height);
    	this.Ime_Igraca = Ime_Igraca;
    	this.health = health;	
    			
    }

	}

}
