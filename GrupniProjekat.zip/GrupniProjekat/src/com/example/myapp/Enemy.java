package com.example.myapp;

public class Enemy extends GameObject {
	
	private String type;
	private int damage;

	{

	}

}
